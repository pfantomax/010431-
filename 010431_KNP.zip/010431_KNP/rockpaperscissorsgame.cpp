#include "rockpaperscissorsgame.h"
#include <QVBoxLayout>
#include <QStringList>
#include <QRandomGenerator>

RockPaperScissorsGame::RockPaperScissorsGame(QWidget *parent)
    : QWidget(parent) {
    resultLabel = new QLabel("Виберіть один із варіантів:", this);
    resultLabel->setAlignment(Qt::AlignCenter);

    rockButton = new QPushButton("Камінь", this);
    paperButton = new QPushButton("Папір", this);
    scissorsButton = new QPushButton("Ножиці", this);

    connect(rockButton, &QPushButton::clicked, this, [this]() { makeChoice("Камінь"); });
    connect(paperButton, &QPushButton::clicked, this, [this]() { makeChoice("Папір"); });
    connect(scissorsButton, &QPushButton::clicked, this, [this]() { makeChoice("Ножиці"); });

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(resultLabel);
    layout->addWidget(rockButton);
    layout->addWidget(paperButton);
    layout->addWidget(scissorsButton);

    setLayout(layout);
}

void RockPaperScissorsGame::makeChoice(const QString &playerChoice) {
    QStringList choices = {"Камінь", "Папір", "Ножиці"};
    QString computerChoice = choices.at(QRandomGenerator::global()->bounded(3));

    QString result = getWinner(playerChoice, computerChoice);

    QString resultText = QString("Ваш вибір: %1\nВибір комп'ютера: %2\nРезультат: %3")
                             .arg(playerChoice, computerChoice, result);
    resultLabel->setText(resultText);
}

QString RockPaperScissorsGame::getWinner(const QString &playerChoice, const QString &computerChoice) {
    if (playerChoice == computerChoice) {
        return "Нічия";
    } else if ((playerChoice == "Камінь" && computerChoice == "Ножиці") ||
               (playerChoice == "Папір" && computerChoice == "Камінь") ||
               (playerChoice == "Ножиці" && computerChoice == "Папір")) {
        return "Ви перемогли!";
    } else {
        return "Комп'ютер переміг.";
    }
}
