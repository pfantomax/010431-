#ifndef ROCKPAPERSCISSORSGAME_H
#define ROCKPAPERSCISSORSGAME_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>

class RockPaperScissorsGame : public QWidget {
    Q_OBJECT

public:
    RockPaperScissorsGame(QWidget *parent = nullptr);

private slots:
    void makeChoice(const QString &playerChoice);

private:
    QLabel *resultLabel;
    QPushButton *rockButton;
    QPushButton *paperButton;
    QPushButton *scissorsButton;

    QString getWinner(const QString &playerChoice, const QString &computerChoice);
};

#endif // ROCKPAPERSCISSORSGAME_H
